#ifndef GRAPHCLASS_H
#define GRAPHCLASS_H
class GraphClass{

};
#endif