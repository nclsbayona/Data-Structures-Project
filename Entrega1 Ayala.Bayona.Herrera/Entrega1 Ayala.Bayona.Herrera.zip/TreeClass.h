#ifndef TREECLASS_H
#define TREECLASS_H
class TreeClass{

};

#endif